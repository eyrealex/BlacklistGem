# frozen_string_literal: true

module Blacklistergem
  VERSION = "0.2.0"
end
